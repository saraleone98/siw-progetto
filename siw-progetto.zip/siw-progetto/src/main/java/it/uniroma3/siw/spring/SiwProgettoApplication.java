package it.uniroma3.siw.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SiwProgettoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SiwProgettoApplication.class, args);
	}

}
