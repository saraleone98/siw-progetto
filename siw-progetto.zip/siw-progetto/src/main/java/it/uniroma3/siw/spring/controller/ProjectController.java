package it.uniroma3.siw.spring.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import it.uniroma3.siw.spring.controller.session.SessionData;
import it.uniroma3.siw.spring.controller.validator.ProjectValidator;
import it.uniroma3.siw.spring.model.Project;
import it.uniroma3.siw.spring.model.Task;
import it.uniroma3.siw.spring.model.User;
import it.uniroma3.siw.spring.service.CredentialsService;
import it.uniroma3.siw.spring.service.ProjectService;
import it.uniroma3.siw.spring.service.UserService;

@Controller
public class ProjectController {

	@Autowired
	ProjectService projectService;

	@Autowired
	UserService userService;

	@Autowired
	CredentialsService credentialsService;

	@Autowired
	ProjectValidator projectValidator;

	@Autowired
	SessionData sessionData;

	/*
	 * Questo metodo intercetta le richieste GET all'URL "/projects", crea una lista
	 * con i progetti di cui l'utente loggato è proprietario e restituisce la vista
	 * "myOwnedProjects"
	 */
	@RequestMapping(value = { "/projects" }, method = RequestMethod.GET)
	public String myOwnedProjects(Model model) {
		User loggedUser = sessionData.getLoggedUser();
		List<Project> projectsList = projectService.findByOwner(loggedUser);
		model.addAttribute("loggedUser", loggedUser);
		model.addAttribute("projectsList", projectsList);
		return "myOwnedProjects";
	}

	/*
	 * Questo metodo intercetta le richieste GET mandate da "myOwnedProjects" e se
	 * restituisce la vista "project"
	 */
	@RequestMapping(value = { "/projects/{projectId}" }, method = RequestMethod.GET)
	public String project(Model model, @PathVariable Long projectId) {
		User loggedUser = sessionData.getLoggedUser();
		Project project = projectService.findById(projectId);
		if (project == null)
			return "redirect:/projects";

		List<User> members = userService.getUsers(project);
		if (!project.getOwner().equals(loggedUser) && !members.contains(loggedUser))
			return "redirect:/projects";

		List<Task> tasks = project.getTasks();
		model.addAttribute("loggedUser", loggedUser);
		model.addAttribute("project", project);
		model.addAttribute("members", members);
		model.addAttribute("tasks", tasks);
		return "project";
	}

	/*
	 * Questo metodo intercetta le richieste GET all'URL "/projects/shared", crea
	 * una lista con i progetti condivisi con l'utente loggato e restituisce la
	 * vista "myVisibleProjects"
	 */
	@RequestMapping(value = { "/projects/shared" }, method = RequestMethod.GET)
	public String myVisibleProjects(Model model) {
		User loggedUser = sessionData.getLoggedUser();
		List<Project> sharedProjectsList = projectService.findByUsers(loggedUser);
		model.addAttribute("loggedUser", loggedUser);
		model.addAttribute("sharedProjectsList", sharedProjectsList);
		return "myVisibleProjects";
	}

	/*
	 * Questo metodo intercetta le richieste GET all'URL
	 * "/projects/shared/{projectId}" e restituisce la vista "projectShared"
	 */
	@RequestMapping(value = { "/projects/shared/{projectId}" }, method = RequestMethod.GET)
	public String sharedProject(Model model, @PathVariable Long projectId) {
		User loggedUser = sessionData.getLoggedUser();
		Project project = projectService.findById(projectId);
		if (project == null)
			return "redirect:/projects/shared";

		List<User> members = userService.getUsers(project);
		if (!project.getOwner().equals(loggedUser) && !members.contains(loggedUser))
			return "redirect:/projects/shared";

		model.addAttribute("loggedUser", loggedUser);
		model.addAttribute("project", project);
		model.addAttribute("members", members);
		return "projectShared";
	}

	/*
	 * Questo metodo intercetta le richieste GET all'URL "/projects/add", crea un
	 * nuovo Project. Infine restituisce la vista "addProject"
	 */
	@RequestMapping(value = { "/projects/add" }, method = RequestMethod.GET)
	public String createProjectForm(Model model) {
		User loggedUser = sessionData.getLoggedUser();
		model.addAttribute("loggedUser", loggedUser);
		model.addAttribute("projectForm", new Project());
		return "addProject";
	}

	/*
	 * Questo metodo intercetta le richieste POST mandate all'URL "/projects/add",
	 * riceve i dati immessi nella form e lancia la validazione. Se non ci sono
	 * errori aggiungiamo l'oggetto User a Project e salviamo. Infine si restituisce
	 * la vista "/projects/{projectId}". Se ci sono errori invece restituisce la
	 * vista "addProject"
	 */
	@RequestMapping(value = { "/projects/add" }, method = RequestMethod.POST)
	public String createProject(@Valid @ModelAttribute("projectForm") Project project,
			BindingResult projectBindingResult, Model model) {
		User loggedUser = sessionData.getLoggedUser();
		projectValidator.validate(project, projectBindingResult);
		if (!projectBindingResult.hasErrors()) {
			project.setOwner(loggedUser);
			this.projectService.saveProject(project);
			return "redirect:/projects/" + project.getId();
		}
		model.addAttribute("loggedUser", loggedUser);
		return "addProject";
	}

	/*
	 * Questo metodo intercetta le richieste GET all'URL
	 * "/projects/{projectId}/share", crea una lista con tutti gli utenti escluso
	 * l'utente loggato e restituisce la vista "shareProject"
	 */
	@RequestMapping(value = { "/projects/{projectId}/share" }, method = RequestMethod.GET)
	public String shareProjectForm(Model model, @PathVariable Long projectId) {
		User loggedUser = sessionData.getLoggedUser();
		Project project = projectService.findById(projectId);

		if (!project.getOwner().equals(loggedUser))
			return "redirect:/projects/" + project.getId();

		List<User> members = userService.getUsers(project);
		List<User> usersList = userService.getAllUsers();
		model.addAttribute("loggedUser", loggedUser);
		model.addAttribute("project", project);
		model.addAttribute("members", members);
		model.addAttribute("usersList", usersList);
		return "shareProject";
	}

	/*
	 * Questo metodo intercetta le richieste POST all'URL mandate all'URL
	 * "/projects/{projectId}/share/{userId}" e restituisce la vista
	 * "operationSuccessful" dopo aver eseguito con successo la condivisione
	 */
	@RequestMapping(value = { "/projects/{projectId}/share/{userId}" }, method = RequestMethod.POST)
	public String shareProject(@ModelAttribute("project") Project project, @PathVariable Long projectId,
			@PathVariable Long userId, Model model) {

		Project projectUpdate = projectService.findById(projectId);
		User userUpdate = userService.getUser(userId);
		project = projectService.shareProjectWithUser(projectUpdate, userUpdate);
		List<User> usersList = userService.getUsers(projectUpdate);
		model.addAttribute("project", projectUpdate);
		model.addAttribute("user", userUpdate);
		model.addAttribute("usersList", usersList);
		return "operationSuccessful";
	}

	/*
	 * Questo metodo intercetta le richieste POST mandate all'URL
	 * "/projects/{projectId}/delete" e cancella il progetto a cui appartiene l'id
	 * passato come parametro
	 */
	@RequestMapping(value = { "/projects/{projectId}/delete" }, method = RequestMethod.POST)
	public String removeProject(Model model, @PathVariable Long projectId) {
		this.projectService.deleteProjectById(projectId);
		return "redirect:/projects";
	}

	/*
	 * Questo metodo intercetta le richieste GET all'URL
	 * "/projects/{projectId}/update" e restituisce la vista "updateProject"
	 */
	@RequestMapping(value = { "/projects/{projectId}/update" }, method = RequestMethod.GET)
	public String updateProjectForm(Model model, @PathVariable Long projectId) {
		Project project = projectService.findById(projectId);
		model.addAttribute("projectForm", project);
		return "updateProject";
	}

	/*
	 * Questo metodo intercetta le richieste POST mandate all'URL
	 * "/projects/{projectId}/update" ed aggiorna il progetto a cui appartiene l'id
	 * passato come parametro con i dati immessi nella form. Restituisce la vista
	 * "/projects/{projectId}" se l'aggiornamento viene eseguito con successo,
	 * altrimenti restituisce "updateProject"
	 */
	@RequestMapping(value = { "/projects/{projectId}/update" }, method = RequestMethod.POST)
	public String updateProject(@Valid @ModelAttribute("projectForm") Project project,
			BindingResult projectBindingResult, @PathVariable Long projectId, Model model) {

		projectValidator.validate(project, projectBindingResult);
		Project projectUpdate = projectService.findById(projectId);

		if (!projectBindingResult.hasErrors()) {
			projectUpdate.setName(project.getName());
			projectUpdate.setDescription(project.getDescription());
			projectService.saveProject(projectUpdate);
			return "redirect:/projects/" + projectUpdate.getId();
		}
		return "updateProject";
	}
}
