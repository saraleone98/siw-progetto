package it.uniroma3.siw.spring.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import it.uniroma3.siw.spring.controller.session.SessionData;
import it.uniroma3.siw.spring.controller.validator.TagValidator;
import it.uniroma3.siw.spring.model.Project;
import it.uniroma3.siw.spring.model.Tag;
import it.uniroma3.siw.spring.model.Task;
import it.uniroma3.siw.spring.model.User;
import it.uniroma3.siw.spring.service.ProjectService;
import it.uniroma3.siw.spring.service.TagService;
import it.uniroma3.siw.spring.service.TaskService;

@Controller
public class TagController {

	@Autowired
	ProjectService projectService;

	@Autowired
	TaskService taskService;

	@Autowired
	TagService tagService;

	@Autowired
	TagValidator tagValidator;

	@Autowired
	SessionData sessionData;

	/*
	 * Questo metodo intercetta le richieste GET all'URL
	 * "/projects/{projectId}/tags/add", crea un nuovo oggetto Tag e restituisce la
	 * vista "addTagToProject"
	 */
	@RequestMapping(value = { "/projects/{projectId}/tags/add" }, method = RequestMethod.GET)
	public String addTagToProjectForm(Model model, @PathVariable Long projectId) {
		User loggedUser = sessionData.getLoggedUser();
		Project project = projectService.findById(projectId);
		model.addAttribute("loggedUser", loggedUser);
		model.addAttribute("project", project);
		model.addAttribute("tagForm", new Tag());
		return "addTagToProject";
	}

	/*
	 * Questo metodo intercetta le richieste POST mandate all'URL
	 * "/projects/{projectId}/tags/add", riceve i dati immessi nella form e lancia
	 * la validazione. Se non ci sono errori aggiungiamo l'oggetto Tag a Project e
	 * salviamo. Infine si restituisce la vista "/projects/{projectId}". Se ci sono
	 * errori invece restituisce la vista "addTagToProject"
	 */
	@RequestMapping(value = { "/projects/{projectId}/tags/add" }, method = RequestMethod.POST)
	public String addTagToProject(@Valid @ModelAttribute("tagForm") Tag tag, BindingResult tagBindingResult,
			@ModelAttribute("project") Project project, @PathVariable Long projectId, Model model) {
		User loggedUser = sessionData.getLoggedUser();
		Project projectUpdate = projectService.findById(projectId);
		tagValidator.validate(tag, tagBindingResult);

		if (!tagBindingResult.hasErrors()) {
			this.tagService.saveTag(tag);
			projectUpdate.addTag(tag);
			this.projectService.saveProject(projectUpdate);
			return "redirect:/projects/" + projectUpdate.getId();
		}

		model.addAttribute("loggedUser", loggedUser);
		model.addAttribute("project", projectUpdate);
		return "addTagToProject";
	}

	/*
	 * Questo metodo intercetta le richieste GET all'URL
	 * "/projects/{projectId}/tasks/{taskId}/tags/add", crea un nuovo oggetto Tag e
	 * restituisce la vista "addTagToTask"
	 */
	@RequestMapping(value = { "/projects/{projectId}/tasks/{taskId}/tags/add" }, method = RequestMethod.GET)
	public String addTagToTaskForm(Model model, @PathVariable Long projectId, @PathVariable Long taskId) {
		User loggedUser = sessionData.getLoggedUser();
		Project project = projectService.findById(projectId);
		Task task = taskService.findById(taskId);
		model.addAttribute("loggedUser", loggedUser);
		model.addAttribute("project", project);
		model.addAttribute("task", task);
		model.addAttribute("tagForm", new Tag());
		return "addTagToTask";
	}

	/*
	 * Questo metodo intercetta le richieste POST mandate all'URL
	 * "/projects/{projectId}/tasks/{taskId}/tags/add", riceve i dati immessi nella
	 * form e lancia la validazione. Se non ci sono errori aggiungiamo l'oggetto Tag
	 * a Task e salviamo. Infine si restituisce la vista "/projects/{projectId}". Se
	 * ci sono errori invece restituisce la vista "addTagToTask"
	 */
	@RequestMapping(value = { "/projects/{projectId}/tasks/{taskId}/tags/add" }, method = RequestMethod.POST)
	public String addTagToTask(@Valid @ModelAttribute("tagForm") Tag tag, BindingResult tagBindingResult,
			@ModelAttribute("task") Task task, @PathVariable Long projectId, @PathVariable Long taskId, Model model) {
		User loggedUser = sessionData.getLoggedUser();
		Project project = projectService.findById(projectId);
		Task taskUpdate = taskService.findById(taskId);
		tagValidator.validate(tag, tagBindingResult);

		if (!tagBindingResult.hasErrors()) {
			tag.addAssociatedTask(taskUpdate);
			taskUpdate.addUsedTag(tag);
			this.taskService.saveTask(taskUpdate);
			return "redirect:/projects/" + project.getId();
		}

		model.addAttribute("loggedUser", loggedUser);
		return "addTagToTask";
	}

}
