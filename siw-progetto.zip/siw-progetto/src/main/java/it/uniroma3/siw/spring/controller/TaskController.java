package it.uniroma3.siw.spring.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import it.uniroma3.siw.spring.controller.session.SessionData;
import it.uniroma3.siw.spring.controller.validator.TaskValidator;
import it.uniroma3.siw.spring.model.Project;
import it.uniroma3.siw.spring.model.Task;
import it.uniroma3.siw.spring.model.User;
import it.uniroma3.siw.spring.service.ProjectService;
import it.uniroma3.siw.spring.service.TaskService;
import it.uniroma3.siw.spring.service.UserService;

@Controller
public class TaskController {

	@Autowired
	TaskService taskService;

	@Autowired
	SessionData sessionData;

	@Autowired
	ProjectService projectService;

	@Autowired
	UserService userService;

	@Autowired
	TaskValidator taskValidator;

	/*
	 * Questo metodo intercetta le richieste GET all'URL
	 * "/projects/{projectId}/tasks/add", crea un nuovo oggetto Task e restituisce
	 * la vista "addTask"
	 */
	@RequestMapping(value = { "/projects/{projectId}/tasks/add" }, method = RequestMethod.GET)
	public String createTaskForm(Model model, @PathVariable Long projectId) {
		User loggedUser = sessionData.getLoggedUser();
		Project project = projectService.findById(projectId);
		model.addAttribute("loggedUser", loggedUser);
		model.addAttribute("project", project);
		model.addAttribute("taskForm", new Task());
		return "addTask";
	}

	/*
	 * Questo metodo intercetta le richieste POST mandate all'URL
	 * "/projects/{projectId}/tasks/add", riceve i dati immessi nella form e lancia
	 * la validazione. Se non ci sono errori aggiungiamo l'oggetto Task a Project e
	 * salviamo. Infine si restituisce la vista "/projects/{projectId}". Se ci sono
	 * errori invece restituisce la vista "addTask"
	 */
	@RequestMapping(value = { "/projects/{projectId}/tasks/add" }, method = RequestMethod.POST)
	public String createTask(@Valid @ModelAttribute("taskForm") Task task, BindingResult taskBindingResult,
			@ModelAttribute("project") Project project, @PathVariable Long projectId, Model model) {

		User loggedUser = sessionData.getLoggedUser();
		Project projectUpdate = projectService.findById(projectId);
		taskValidator.validate(task, taskBindingResult);

		if (!taskBindingResult.hasErrors()) {
			task.setOwner(loggedUser);
			task.setCompleted(false);
			projectUpdate.addTask(task);
			this.projectService.saveProject(projectUpdate);
			return "redirect:/projects/" + projectUpdate.getId();
		}
		model.addAttribute("loggedUser", loggedUser);
		model.addAttribute("project", project);
		return "addTask";
	}

	/*
	 * Questo metodo intercetta le richieste GET all'URL
	 * "/projects/{projectId}/tasks/{taskId}/assign", crea una lista con tutti gli
	 * utenti che hanno visibilità sul progetto e restituisce la vista "assignTask"
	 */
	@RequestMapping(value = { "/projects/{projectId}/tasks/{taskId}/assign" }, method = RequestMethod.GET)
	public String updateOwnerTaskForm(Model model, @PathVariable Long projectId, @PathVariable Long taskId) {
		User loggedUser = sessionData.getLoggedUser();
		Project project = projectService.findById(projectId);
		Task task = taskService.findById(taskId);
		List<User> members = userService.getUsers(project);
		model.addAttribute("user", loggedUser);
		model.addAttribute("project", project);
		model.addAttribute("taskForm", task);
		model.addAttribute("members", members);
		return "assignTask";
	}

	/*
	 * Questo metodo intercetta le richieste POST mandate all'URL
	 * "/projects/{projectId}/tasks/{taskId}/assign/{userId}", aggiorna il task e
	 * restituisce la vista "operationSuccessful" dopo aver eseguito l'assegnazione
	 * con successo
	 */
	@RequestMapping(value = { "/projects/{projectId}/tasks/{taskId}/assign/{userId}" }, method = RequestMethod.POST)
	public String updateOwnerTask(@ModelAttribute("user") User user, @ModelAttribute("project") Project project,
			@ModelAttribute("taskForm") Task task, @PathVariable Long userId, @PathVariable Long projectId,
			@PathVariable Long taskId, Model model) {
		User userUpdate = userService.getUser(userId);
		Project projectUpdate = projectService.findById(projectId);
		Task taskUpdate = taskService.findById(taskId);
		taskService.assignTaskToUser(projectUpdate, taskUpdate, userUpdate);
		model.addAttribute("project", projectUpdate);
		return "operationSuccessful";
	}

	/*
	 * Questo metodo intercetta le richieste POST mandate all'URL
	 * "/projects/{projectId}/{taskId}/completed", aggiorna il task e restituisce la
	 * vista "/projects/{projectId}"
	 */
	@RequestMapping(value = { "/projects/{projectId}/{taskId}/completed" }, method = RequestMethod.POST)
	public String taskCompleted(Model model, @PathVariable Long projectId, @PathVariable Long taskId) {
		Project project = projectService.findById(projectId);
		Task task = taskService.findById(taskId);
		task.setCompleted(true);
		this.taskService.saveTask(task);
		return "redirect:/projects/" + project.getId();
	}

}
