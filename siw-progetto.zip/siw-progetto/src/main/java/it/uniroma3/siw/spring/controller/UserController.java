package it.uniroma3.siw.spring.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import it.uniroma3.siw.spring.controller.session.SessionData;
import it.uniroma3.siw.spring.controller.validator.CredentialsValidator;
import it.uniroma3.siw.spring.controller.validator.UserValidator;
import it.uniroma3.siw.spring.model.Credentials;
import it.uniroma3.siw.spring.model.User;
import it.uniroma3.siw.spring.service.CredentialsService;
import it.uniroma3.siw.spring.service.UserService;

@Controller
public class UserController {

	@Autowired
	SessionData sessionData;

	@Autowired
	CredentialsService credentialsService;

	@Autowired
	UserService userService;

	@Autowired
	UserValidator userValidator;

	@Autowired
	CredentialsValidator credentialsValidator;

	/*
	 * Questo metodo intercetta le richieste GET all'URL "/home" e restituisce la
	 * vista "home"
	 */
	@RequestMapping(value = { "/home" }, method = RequestMethod.GET)
	public String home(Model model) {
		User loggedUser = sessionData.getLoggedUser();
		model.addAttribute("user", loggedUser);
		return "home";
	}

	/*
	 * Questo metodo intercetta le richieste GET all'URL "/users/me" e restituisce
	 * la vista "userProfile"
	 */
	@RequestMapping(value = { "/users/me" }, method = RequestMethod.GET)
	public String me(Model model) {
		User loggedUser = sessionData.getLoggedUser();
		Credentials credentials = sessionData.getLoggedCredentials();
		model.addAttribute("userForm", loggedUser);
		model.addAttribute("credentialsForm", credentials);
		return "userProfile";
	}

	/*
	 * Questo metodo intercetta le richieste GET all'URL "/admin" e restituisce la
	 * vista "admin" (se si hanno le credenziali adatte alla sua visualizzazione)
	 */
	@RequestMapping(value = { "/admin" }, method = RequestMethod.GET)
	public String admin(Model model) {
		User loggedUser = sessionData.getLoggedUser();
		model.addAttribute("user", loggedUser);
		return "admin";
	}

	/*
	 * Questo metodo intercetta le richieste GET all'URL "/admin/users" , crea una
	 * lista con le credenziali di tutti gli utenti e restituisce la vista
	 * "allUsers" (se si hanno le credenziali adatte alla sua visualizzazione)
	 */
	@RequestMapping(value = { "/admin/users" }, method = RequestMethod.GET)
	public String usersList(Model model) {
		User loggedUser = sessionData.getLoggedUser();
		List<Credentials> allCredentials = this.credentialsService.getAllCredentials();
		model.addAttribute("loggedUser", loggedUser);
		model.addAttribute("credentialsList", allCredentials);
		return "allUsers";
	}

	/*
	 * Questo metodo intercetta le richieste POST mandate all'URL
	 * "/admin/users/{username}/delete" e cancella l'user a cui appartiene
	 * l'username passato come parametro
	 */
	@RequestMapping(value = { "/admin/users/{username}/delete" }, method = RequestMethod.POST)
	public String removeUser(Model model, @PathVariable String username) {
		this.credentialsService.deleteCredentials(username);
		return "redirect:/admin/users";
	}

	/*
	 * Questo metodo intercetta le richieste GET all'URL "/users/me/update" e
	 * restituisce la vista "updateProfile"
	 */
	@RequestMapping(value = { "/users/me/update" }, method = RequestMethod.GET)
	public String updateProfileForm(Model model) {
		User loggedUser = sessionData.getLoggedUser();
		Credentials credentials = sessionData.getLoggedCredentials();
		model.addAttribute("userForm", loggedUser);
		model.addAttribute("credentialsForm", credentials);
		return "updateProfile";
	}

	/*
	 * Questo metodo intercetta le richieste POST mandate all'URL "/users/me/update"
	 * ed aggiorna le credenziali con i dati immessi nella form. Restituisce
	 * "/users/me" se l'aggiornamento è eseguito con successo, altrimenti
	 * restituisce "updateProfile"
	 */
	@RequestMapping(value = { "/users/me/update" }, method = RequestMethod.POST)
	public String updateProfile(@Valid @ModelAttribute("userForm") User user, BindingResult userBindingResult,
			@Valid @ModelAttribute("credentialsForm") Credentials credentials, BindingResult credentialsBindingResult,
			Model model) {
		User loggedUser = sessionData.getLoggedUser();
		Credentials loggedCredentials = sessionData.getLoggedCredentials();
		credentials.setId(loggedCredentials.getId());
		user.setId(loggedUser.getId());

		this.userValidator.validate(user, userBindingResult);
		if (!credentials.getUsername().equals(loggedCredentials.getUsername())) {
			this.credentialsValidator.validate(credentials, credentialsBindingResult);
		}

		if (!userBindingResult.hasErrors() && !credentialsBindingResult.hasErrors()) {
			credentials.setUser(user);
			credentialsService.saveCredentials(credentials);
			return "redirect:/users/me";
		}

		return "updateProfile";

	}

}
