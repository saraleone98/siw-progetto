package it.uniroma3.siw.spring.controller.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import it.uniroma3.siw.spring.model.Credentials;
import it.uniroma3.siw.spring.service.CredentialsService;

@Component
public class CredentialsValidator implements Validator {
	
	@Autowired 
	CredentialsService credentialsService;
	
	public void validate(Object o, Errors errors) {
		Credentials credentials = (Credentials) o;
		String username = credentials.getUsername().trim();
		String password = credentials.getPassword().trim();
		
		if(username==null || username.isEmpty()) {
			errors.rejectValue("username", "required");
		}
		else if(this.credentialsService.getCredentials(username)!=null) {
			errors.rejectValue("username", "duplicate");
		}
		
		if(password==null || password.isEmpty()) {
			errors.rejectValue("password", "required");
		}
	}
	
	@Override
	public boolean supports(Class<?> clazz) {
		return Credentials.class.equals(clazz);
	}
	
}
