package it.uniroma3.siw.spring.controller.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import it.uniroma3.siw.spring.model.Task;

@Component
public class TaskValidator implements Validator {

	public void validate(Object o, Errors errors) {
		Task task = (Task) o;
		String name = task.getName().trim();

		if (name == null || name.isEmpty()) {
			errors.rejectValue("name", "required");
		}
	}

	@Override
	public boolean supports(Class<?> clazz) {
		return Task.class.equals(clazz);
	}

}
