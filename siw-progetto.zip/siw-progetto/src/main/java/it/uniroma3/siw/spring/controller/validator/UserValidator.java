package it.uniroma3.siw.spring.controller.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import it.uniroma3.siw.spring.model.User;

@Component
public class UserValidator implements Validator {
	
	public void validate(Object o, Errors errors) {
		User user = (User) o;
		String firstName = user.getFirstName().trim();
		String lastName = user.getLastName().trim();
		
		if(firstName==null || firstName.isEmpty()) {
			errors.rejectValue("firstName", "required");
		}
		
		if(lastName==null || lastName.isEmpty()) {
			errors.rejectValue("lastName", "required");
		}
	}

	@Override
	public boolean supports(Class<?> clazz) {
		return User.class.equals(clazz);
	}

}
