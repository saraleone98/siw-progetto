package it.uniroma3.siw.spring.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import it.uniroma3.siw.spring.model.Project;
import it.uniroma3.siw.spring.model.User;

public interface ProjectRepository extends CrudRepository<Project, Long> {

	public List<Project> findByUsers(User user);

	public List<Project> findByOwner(User owner);

	public void deleteById(Long id);

}
