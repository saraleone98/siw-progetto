package it.uniroma3.siw.spring.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import it.uniroma3.siw.spring.model.Tag;
import it.uniroma3.siw.spring.model.Task;

public interface TagRepository extends CrudRepository<Tag, Long> {

	public List<Tag> findByAssociatedTasks(Task task);

}
