package it.uniroma3.siw.spring.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import it.uniroma3.siw.spring.model.Project;
import it.uniroma3.siw.spring.model.User;
import it.uniroma3.siw.spring.repository.ProjectRepository;

@Service
public class ProjectService {

	@Autowired
	protected ProjectRepository projectRepository;

	/* Cerca Project nel DB tramite il suo id */
	@Transactional
	public Project findById(Long id) {
		Optional<Project> result = this.projectRepository.findById(id);
		return result.orElse(null);
	}

	/* Cerca Projects nel DB tramite il suo proprietario */
	@Transactional
	public List<Project> findByOwner(User owner) {
		List<Project> result = new ArrayList<>();
		Iterable<Project> iterable = this.projectRepository.findByOwner(owner);
		for (Project project : iterable)
			result.add(project);
		return result;
	}

	/* Cerca Projects nel DB tramite users che hanno visibilità */
	@Transactional
	public List<Project> findByUsers(User user) {
		List<Project> result = new ArrayList<>();
		Iterable<Project> iterable = this.projectRepository.findByUsers(user);
		for (Project project : iterable)
			result.add(project);
		return result;
	}

	/* Salva Project nel DB */
	@Transactional
	public Project saveProject(Project project) {
		return this.projectRepository.save(project);
	}

	/* Cancella Project nel DB */
	@Transactional
	public void deleteProject(Project project) {
		this.projectRepository.delete(project);
	}

	/* Cancella Project nel DB tramite il suo id */
	@Transactional
	public void deleteProjectById(Long id) {
		this.projectRepository.deleteById(id);
	}

	/* Salva il progetto tra quelli condivisi di un utente */
	@Transactional
	public Project shareProjectWithUser(Project project, User user) {
		project.addMember(user);
		return this.projectRepository.save(project);
	}

}
