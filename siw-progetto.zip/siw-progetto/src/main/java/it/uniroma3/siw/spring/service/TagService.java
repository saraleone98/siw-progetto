package it.uniroma3.siw.spring.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import it.uniroma3.siw.spring.model.Tag;
import it.uniroma3.siw.spring.repository.TagRepository;

@Service
public class TagService {

	@Autowired
	protected TagRepository tagRepository;

	/* Cerca Tag nel DB tramite il suo id */
	@Transactional
	public Tag getTag(Long id) {
		Optional<Tag> result = this.tagRepository.findById(id);
		return result.orElse(null);
	}

	/* Salva Tag nel DB */
	@Transactional
	public Tag saveTag(Tag tag) {
		return this.tagRepository.save(tag);
	}

	/* Cancella Tag nel DB */
	@Transactional
	public void deleteTag(Tag tag) {
		this.tagRepository.delete(tag);
	}

}
