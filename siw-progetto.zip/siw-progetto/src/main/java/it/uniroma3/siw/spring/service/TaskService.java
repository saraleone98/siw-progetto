package it.uniroma3.siw.spring.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import it.uniroma3.siw.spring.model.Project;
import it.uniroma3.siw.spring.model.Task;
import it.uniroma3.siw.spring.model.User;
import it.uniroma3.siw.spring.repository.TaskRepository;

@Service
public class TaskService {

	@Autowired
	protected TaskRepository taskRepository;

	/* Cerca Task nel DB tramite il suo id */
	@Transactional
	public Task findById(Long id) {
		Optional<Task> result = this.taskRepository.findById(id);
		return result.orElse(null);
	}

	/* Salva Task nel DB */
	@Transactional
	public Task saveTask(Task task) {
		return this.taskRepository.save(task);
	}

	/* Cancella Task nel DB */
	@Transactional
	public void deleteTask(Task task) {
		this.taskRepository.delete(task);
	}

	/* Aggiorna l'user assegnato al task */
	@Transactional
	public Task assignTaskToUser(Project project, Task task, User user) {
		task.setOwner(user);
		return this.taskRepository.save(task);
	}

}
