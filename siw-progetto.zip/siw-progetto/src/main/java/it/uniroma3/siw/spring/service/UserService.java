package it.uniroma3.siw.spring.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import it.uniroma3.siw.spring.model.Project;
import it.uniroma3.siw.spring.model.User;
import it.uniroma3.siw.spring.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	protected UserRepository userRepository;

	@Autowired
	protected PasswordEncoder passwordEncoder;

	/* Cerca User nel DB tramite il suo id */
	@Transactional
	public User getUser(Long id) {
		Optional<User> result = this.userRepository.findById(id);
		return result.orElse(null);
	}

	/* Cerca User nel DB tramite il suo username */
	@Transactional
	public User getUser(String username) {
		Optional<User> result = this.userRepository.findByUsername(username);
		return result.orElse(null);
	}

	/* Cerca User nel DB tramite un progetto di cui l'user è proprietario */
	@Transactional
	public User getUser(Project project) {
		User result = this.userRepository.findByOwnedProjects(project);
		return result;
	}

	/* Cerca Users nel DB tramite un progetto di cui gli users hanno visibilità */
	@Transactional
	public List<User> getUsers(Project project) {
		List<User> result = new ArrayList<>();
		Iterable<User> iterable = this.userRepository.findByVisibleProjects(project);
		for (User user : iterable)
			result.add(user);
		return result;
	}

	/* Cerca tutti gli Users presenti nel DB */
	@Transactional
	public List<User> getAllUsers() {
		List<User> result = new ArrayList<>();
		Iterable<User> iterable = this.userRepository.findAll();
		for (User user : iterable)
			result.add(user);
		return result;
	}

	/* Salva l'User nel DB */
	@Transactional
	public User saveUser(User user) {
		user.setPassword(this.passwordEncoder.encode(user.getPassword()));
		return this.userRepository.save(user);
	}

}
