package it.uniroma3.siw.spring;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import java.time.LocalDate;
import java.util.List;

import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import it.uniroma3.siw.spring.model.Credentials;
import it.uniroma3.siw.spring.model.Project;
import it.uniroma3.siw.spring.model.Tag;
import it.uniroma3.siw.spring.model.Task;
import it.uniroma3.siw.spring.model.User;
import it.uniroma3.siw.spring.repository.ProjectRepository;
import it.uniroma3.siw.spring.repository.TagRepository;
import it.uniroma3.siw.spring.repository.TaskRepository;
import it.uniroma3.siw.spring.repository.UserRepository;
import it.uniroma3.siw.spring.service.CredentialsService;
import it.uniroma3.siw.spring.service.ProjectService;
import it.uniroma3.siw.spring.service.TagService;
import it.uniroma3.siw.spring.service.TaskService;
import it.uniroma3.siw.spring.service.UserService;

@SpringBootTest
@RunWith(SpringRunner.class)
class SiwProgettoApplicationTests {

	@Autowired
	private UserRepository userRepository;
	@Autowired
	private TaskRepository taskRepository;
	@Autowired
	private ProjectRepository projectRepository;
	@Autowired
	private TagRepository tagRepository;
	@Autowired
	private UserService userService;
	@Autowired
	private TaskService taskService;
	@Autowired
	private ProjectService projectService;
	@Autowired
	private CredentialsService credentialsService;
	@Autowired
	private TagService tagService;

	@Before
	public void deleteAll() {
		System.out.println("Deleting all data...");
		this.userRepository.deleteAll();
		this.taskRepository.deleteAll();
		this.projectRepository.deleteAll();
		this.tagRepository.deleteAll();
		System.out.println("Done");
	}

	@Test
	void testUpdateUser() {
		User user1 = new User("mariorossi", "password1", "Mario", "Rossi", LocalDate.now());
		user1 = userService.saveUser(user1);
		assertEquals(user1.getId().longValue(), 1L);
		assertEquals(user1.getUsername(), "mariorossi");

		User user2 = new User("lucabianchi", "password2", "Luca", "Bianchi", LocalDate.now());
		user2 = userService.saveUser(user2);
		assertEquals(user2.getId().longValue(), 2L);
		assertEquals(user2.getUsername(), "lucabianchi");

		User user1Update = new User("mariarossi", "password", "Maria", "Rossi", LocalDate.now());
		user1Update.setId(user1.getId());
		user1Update = userService.saveUser(user1Update);
		assertEquals(user1Update.getId().longValue(), 1L);
		assertEquals(user1Update.getUsername(), "mariarossi");

		Project project1 = new Project("testproject1", "This is test project1");
		project1.setOwner(user1Update);
		project1 = projectService.saveProject(project1);
		assertEquals(project1.getOwner(), user1Update);
		assertEquals(project1.getName(), "testproject1");

		Project project2 = new Project("testproject2", "This is test project2");
		project2.setOwner(user1Update);
		project2 = projectService.saveProject(project2);
		assertEquals(project2.getOwner(), user1Update);
		assertEquals(project2.getName(), "testproject2");

		Project project3 = new Project("testproject3", "This is test project3");
		project3.setOwner(user1Update);
		project3 = projectService.saveProject(project3);
		assertEquals(project3.getOwner(), user1Update);
		assertEquals(project3.getName(), "testproject3");
		assertFalse(user2.isAVisibleProject(project3));

		project1 = projectService.shareProjectWithUser(project1, user2);
		List<Project> projects = projectRepository.findByOwner(user1Update);
		assertEquals(projects.size(), 3);
		assertEquals(projects.get(0), project1);
		assertEquals(projects.get(1), project2);
		List<Project> visibleProjects = projectRepository.findByUsers(user2);
		assertEquals(visibleProjects.size(), 1);

		Task task1 = new Task("task1", "questo è task 1", false);
		Task task2 = new Task("task2", "questo è task2", false);
		task1.setOwner(user1Update); // dovrebbe subito assegnare il task al proprietario del progetto alla creazione
		task2.setOwner(user1Update); // non dovrebbe essere necessario farlo manualmente
		task1 = taskService.saveTask(task1);
		task2 = taskService.saveTask(task2);
		project1.addTask(task1);
		project2.addTask(task2);
		project1 = projectService.saveProject(project1);
		project2 = projectService.saveProject(project2);
		assertEquals(project1.getTasks().size(), 1);
		task1 = taskService.assignTaskToUser(project1, task1, user2);
		assertEquals(task1.getOwner(), user2);
		assertEquals(task2.getOwner(), user1Update);

		List<Project> projectsVisibleByUser2 = projectRepository.findByUsers(user2);
		assertEquals(projectsVisibleByUser2.size(), 1);
		assertEquals(projectsVisibleByUser2.get(0), project1);

		project2 = projectService.shareProjectWithUser(project2, user2);
		List<Project> projectsVisibleByUser2bis = projectRepository.findByUsers(user2);
		assertEquals(projectsVisibleByUser2bis.size(), 2);
		task2 = taskService.assignTaskToUser(project2, task2, user2);

		List<User> project1Members = userRepository.findByVisibleProjects(project1);
		assertEquals(project1Members.size(), 1);
		assertEquals(project1Members.get(0), user2);

		Tag tag1 = new Tag("tag1", "rosso", "è il tag1");
		Tag tag2 = new Tag("tag2", "blu", "è il tag2");
		Tag tag3 = new Tag("tag3", "verde", "è il tag3");
		Tag tag4 = new Tag("tag4", "arancione", "è il tag4");
		tag1 = tagService.saveTag(tag1);
		tag2 = tagService.saveTag(tag2);
		tag3 = tagService.saveTag(tag3);
		tag4 = tagService.saveTag(tag4);
		project1.addTag(tag1);
		assertEquals(project1.getTags().size(), 1);
		task1.addUsedTag(tag2);
		task1.addUsedTag(tag3);
		assertEquals(task1.getUsedTags().size(), 2);
		task2.addUsedTag(tag4);
		assertEquals(task2.getUsedTags().size(), 1);
		project1 = projectService.saveProject(project1);
		task1 = taskService.saveTask(task1);
		task2 = taskService.saveTask(task2);
		tag2.addAssociatedTask(task1);
		tag3.addAssociatedTask(task1);
		tag4.addAssociatedTask(task2);
		tag2 = tagService.saveTag(tag2);
		tag3 = tagService.saveTag(tag3);
		tag4 = tagService.saveTag(tag4);

		Credentials credentials = new Credentials("username", "pass", "DEFAULT", user1);
		assertEquals(credentials.getUsername(), "username");
		System.out.println(credentials);
		Credentials credentialsUpdate = credentialsService.getCredentials(credentials.getUsername());
		System.out.println(credentialsUpdate);
		User user = userService.getUser(user1.getId());
		System.out.println(user);
	}

}
